# Myocardial Infarction Risk Prediction Using Machine Learning
UE24CS352A Machine Learning mini-project, **Problem 49**: predicting myocardial infarction risk using supervised and unsupervised machine learning methods.

Team: Dhareen G (PES1UG24AM084), Gaurav S. (PES1UG24AM104)

## Problem
1. **Unsupervised:** look for structure in the patient data with PCA, K-Means and DBSCAN.
2. **Supervised:** predict whether a patient is high risk (`target = 1`) from 13 clinical features, and expose the model through a small demo app.

Dataset: Kaggle *Heart Attack Analysis & Prediction* (`heart.csv`). The label means heart-disease presence, not a confirmed MI. The output is an estimated probability for a class project, not medical advice.

## Approach
- Dropped duplicate rows (raw file: 1025 rows, only 302 unique patients) before splitting, so train and test never share a patient
- Treated invalid codes (`ca = 4`, `thal = 0`) as missing and imputed them inside the pipeline
- One sklearn preprocessing pipeline: impute, scale numeric columns, one-hot encode categorical columns
- **Unsupervised:** PCA, K-Means (k chosen by silhouette) and DBSCAN on the preprocessed features; labels are used only afterwards to score clusters (ARI)
- **Supervised:** logistic regression, random forest and gradient boosting compared with 5x5 repeated stratified CV on an 80% training split; final logistic regression evaluated once on the held-out 20% test set (61 patients)
- Extras: threshold analysis, calibration, per-sex performance with bootstrap confidence intervals

## Results
| | |
|---|---|
| PCA | 2 components keep 38.3% of the variance |
| K-Means (k = 2) | silhouette 0.165, ARI 0.251; clusters have 77% vs 27% of `target = 1` |
| DBSCAN (eps 3.0) | 1 cluster + 7 noise points, ARI 0.004 |
| CV AUC (train, 5x5) | 0.920 ± 0.034 (logistic regression) |
| Test AUROC | 0.902 |
| Test accuracy / sensitivity / specificity | 0.836 / 0.848 / 0.821 |
| Brier score | 0.122 |

Tables and figures are in `outputs/` and in `notebook.ipynb`.

## Files
| File | Purpose |
|---|---|
| `notebook.ipynb` | Full analysis, run top to bottom |
| `train.py` | Rebuilds `model.joblib` from `heart.csv` |
| `app.py` | Streamlit demo (single patient form + CSV upload) |
| `model.joblib` | Trained pipeline used by the app |
| `heart.csv` | Dataset |
| `outputs/` | Saved figures and result tables |
| `docs/` | Two-page write-up and review slides (PDF) |

## Setup
```bash
pip install -r requirements.txt
```

## Run
1. **Notebook:** open `notebook.ipynb` in Jupyter or Colab (with `heart.csv` in the same folder) and run all cells.
2. **Demo app:**
   ```bash
   python train.py          # optional: rebuilds model.joblib for your scikit-learn version
   python -m streamlit run app.py
   ```
   Use the *Single patient* tab or upload a CSV in the *Upload CSV* tab (13 feature columns; a `target` column is optional and enables accuracy/AUROC).

If loading `model.joblib` fails with an `AttributeError` or version warning, run `python train.py`: pickled models only load reliably on the scikit-learn version that saved them.

## Dataset
https://www.kaggle.com/datasets/rashikrahmanpritom/heart-attack-analysis-prediction-dataset
