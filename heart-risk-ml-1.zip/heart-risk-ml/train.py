import numpy as np
import pandas as pd
import joblib
from sklearn.model_selection import train_test_split
from sklearn.pipeline import Pipeline
from sklearn.compose import ColumnTransformer
from sklearn.impute import SimpleImputer
from sklearn.preprocessing import StandardScaler, OneHotEncoder
from sklearn.linear_model import LogisticRegression
from sklearn.metrics import roc_auc_score

# Load, dedupe, and mark invalid codes as missing (same as the notebook)
df = pd.read_csv("heart.csv").drop_duplicates().reset_index(drop=True)
df["ca"] = df["ca"].replace(4, np.nan)
df["thal"] = df["thal"].replace(0, np.nan)

X, y = df.drop(columns="target"), df["target"]
num_cols = ["age", "trestbps", "chol", "thalach", "oldpeak"]
cat_cols = ["sex", "cp", "fbs", "restecg", "exang", "slope", "ca", "thal"]

X_train, X_test, y_train, y_test = train_test_split(
    X, y, test_size=0.2, stratify=y, random_state=42
)

prep = ColumnTransformer([
    ("num", Pipeline([("imp", SimpleImputer(strategy="median")),
                      ("sc", StandardScaler())]), num_cols),
    ("cat", Pipeline([("imp", SimpleImputer(strategy="most_frequent")),
                      ("oh", OneHotEncoder(handle_unknown="ignore"))]), cat_cols),
])
final = Pipeline([("prep", prep), ("model", LogisticRegression(max_iter=1000))])
final.fit(X_train, y_train)

print("Rows after dedupe:", len(df))
print("Test AUROC:", round(roc_auc_score(y_test, final.predict_proba(X_test)[:, 1]), 3))

joblib.dump({"pipeline": final, "threshold": 0.5, "columns": X.columns.tolist()}, "model.joblib")
print("saved model.joblib")