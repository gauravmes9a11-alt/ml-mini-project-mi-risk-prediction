import joblib
import numpy as np
import pandas as pd
import streamlit as st
from sklearn.metrics import (accuracy_score, precision_score, recall_score,
                             f1_score, roc_auc_score, confusion_matrix)

st.set_page_config(page_title="Heart Disease Risk Estimator", layout="wide")


@st.cache_resource
def load_bundle():
    return joblib.load("model.joblib")


bundle = load_bundle()
pipe, thr, cols = bundle["pipeline"], bundle["threshold"], bundle["columns"]

# Other copies of this dataset use different column names; map them to ours.
ALIASES = {"trtbps": "trestbps", "thalachh": "thalach", "exng": "exang",
           "slp": "slope", "caa": "ca", "thall": "thal",
           "output": "target", "risk": "target"}

st.title("Heart Disease Risk Estimator")
st.caption("Class project demo. Estimates P(target = 1) from the Kaggle Heart "
           "Attack Analysis & Prediction dataset. Not medical advice.")

tab1, tab2 = st.tabs(["Single patient", "Upload CSV"])

# ---------------------------------------------------------------- single patient
with tab1:
    c1, c2 = st.columns(2)
    with c1:
        age = st.number_input("Age", 20, 90, 55)
        sex = st.selectbox("Sex", [0, 1], format_func=lambda v: "Female" if v == 0 else "Male")
        cp = st.selectbox("Chest pain type (cp)", [0, 1, 2, 3])
        trestbps = st.number_input("Resting blood pressure (mmHg)", 80, 220, 130)
        chol = st.number_input("Cholesterol (mg/dL)", 100, 600, 240)
        fbs = st.selectbox("Fasting blood sugar > 120 mg/dL", [0, 1],
                           format_func=lambda v: "No" if v == 0 else "Yes")
    with c2:
        restecg = st.selectbox("Resting ECG (restecg)", [0, 1, 2])
        thalach = st.number_input("Max heart rate achieved", 60, 220, 150)
        exang = st.selectbox("Exercise-induced angina", [0, 1],
                             format_func=lambda v: "No" if v == 0 else "Yes")
        oldpeak = st.number_input("ST depression (oldpeak)", 0.0, 7.0, 1.0, step=0.1)
        slope = st.selectbox("ST slope (slope)", [0, 1, 2])
        ca = st.selectbox("Major vessels (ca)", [0, 1, 2, 3])
        thal = st.selectbox("Thal (thal)", [1, 2, 3])

    if st.button("Estimate risk"):
        row = {"age": age, "sex": sex, "cp": cp, "trestbps": trestbps, "chol": chol,
               "fbs": fbs, "restecg": restecg, "thalach": thalach, "exang": exang,
               "oldpeak": oldpeak, "slope": slope, "ca": ca, "thal": thal}
        p = float(pipe.predict_proba(pd.DataFrame([row])[cols])[0, 1])
        st.metric("Estimated probability (target = 1)", f"{p:.1%}")
        st.progress(p)
        st.write("Prediction:", "**Higher risk**" if p >= thr else "**Lower risk**")

# ---------------------------------------------------------------- CSV upload
with tab2:
    st.write("Upload a CSV with these columns: `" + "`, `".join(cols) + "`. "
             "A `target` column is optional; if present, accuracy and AUROC are computed.")

    template = pd.DataFrame([{"age": 55, "sex": 1, "cp": 0, "trestbps": 130, "chol": 240,
                              "fbs": 0, "restecg": 1, "thalach": 150, "exang": 0,
                              "oldpeak": 1.0, "slope": 2, "ca": 0, "thal": 2}])[cols]
    st.download_button("Download CSV template", template.to_csv(index=False),
                       "template.csv", "text/csv")

    up = st.file_uploader("Choose a CSV file", type="csv")
    drop_dups = st.checkbox("Drop duplicate rows before scoring", value=True)

    if up is not None:
        try:
            raw = pd.read_csv(up)
        except Exception as e:
            st.error(f"Could not read that file as CSV: {e}")
            st.stop()

        raw.columns = [ALIASES.get(c.strip().lower(), c.strip().lower()) for c in raw.columns]
        missing = [c for c in cols if c not in raw.columns]
        if missing:
            st.error("Missing required columns: " + ", ".join(missing))
            st.stop()

        if drop_dups:
            before = len(raw)
            raw = raw.drop_duplicates().reset_index(drop=True)
            if len(raw) < before:
                st.info(f"Dropped {before - len(raw)} duplicate rows ({len(raw)} remain).")

        # Same cleaning as training: non-numeric -> missing, invalid codes -> missing.
        X = raw[cols].apply(pd.to_numeric, errors="coerce")
        X["ca"] = X["ca"].replace(4, np.nan)
        X["thal"] = X["thal"].replace(0, np.nan)
        n_missing = int(X.isna().sum().sum())
        if n_missing:
            st.warning(f"{n_missing} missing or invalid values were filled in "
                       "automatically (median / most frequent), as in training.")

        probs = pipe.predict_proba(X)[:, 1]
        out = raw.copy()
        out["prob_target_1"] = probs.round(4)
        out["prediction"] = (probs >= thr).astype(int)

        st.subheader("Predictions")
        st.dataframe(out)
        st.download_button("Download predictions", out.to_csv(index=False),
                           "predictions.csv", "text/csv")

        if "target" in raw.columns:
            y = pd.to_numeric(raw["target"], errors="coerce")
            ok = y.isin([0, 1])
            y, pr, pb = y[ok].astype(int), out.loc[ok, "prediction"], probs[ok.values]
            if len(y) and y.nunique() == 2:
                st.subheader("Performance on this file")
                m = st.columns(5)
                m[0].metric("Accuracy", f"{accuracy_score(y, pr):.3f}")
                m[1].metric("AUROC", f"{roc_auc_score(y, pb):.3f}")
                m[2].metric("Precision", f"{precision_score(y, pr):.3f}")
                m[3].metric("Recall", f"{recall_score(y, pr):.3f}")
                m[4].metric("F1", f"{f1_score(y, pr):.3f}")
                cm = pd.DataFrame(confusion_matrix(y, pr, labels=[0, 1]),
                                  index=["actual 0", "actual 1"],
                                  columns=["predicted 0", "predicted 1"])
                st.write("Confusion matrix")
                st.dataframe(cm)
                st.caption("If this file contains patients the model was trained on "
                           "(e.g. the full heart.csv), these numbers will be optimistic.")
            else:
                st.info("Target column found, but it needs both classes (0 and 1) to compute metrics.")
